// INITIALIZED

const express = require( "express" );
const bodyParser = require( "body-parser" );
const date = require( __dirname + "/functions.js" );

const app = express();

const port = 3000;
const items = [ "Buy Food", "Cook Food", "Eat Food" ];
const workItems = [];

app.use( bodyParser.urlencoded( { extended: true } ) );
app.set( "view engine", "ejs" );
app.use( express.static( "public" ) );



// GET

app.get( "/", ( req, res ) => {

  const day = date.getDate();

  res.render( "list", {
    listTitle: day,
    newListItems: items
  });

});

app.get( "/work", ( req, res ) => {
  res.render( "list", {
    listTitle: "Work List",
    newListItems: workItems
  });
});



// POST

app.post( "/", ( req, res ) => {

  const item = req.body.newItem;
  var redir = "/";

  if ( req.body.list === "Work" ) {
    redir += "work";
    workItems.push( item );
  }

  else {
    items.push( item );
  }

  res.redirect( redir );

});



// OTHER

app.listen( port, () => {
  console.log( "Server is running on port " + String( port ) );
});
