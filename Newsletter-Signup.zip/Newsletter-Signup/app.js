// INITIALIZED

const express = require( "express" );
const request = require( "request" );
const bodyParser = require( "body-parser" );
const https = require( "https" );

const app = express();

const localPort = 3000;

app.use( bodyParser.urlencoded( { extended: true } ) );
app.use( express.static( "public" ) )



// GET

app.get( '/', ( req, res ) => {
 res.sendFile( __dirname + "/signup.html" );
});



// POST

app.post( "/", ( req, res ) => {

  const firstName = req.body.fName;
  const lastName = req.body.lName;
  const email = req.body.email;
  const data = {
    members: [
      {
        email_address: email,
        status: "subscribed",
        merge_fields: {
          FNAME: firstName,
          LNAME: lastName
        }
      }
    ]
  };

  const jsonData = JSON.stringify( data );
  const url = "https://us13.api.mailchimp.com/3.0/lists/2bd99be002";
  const options = {

    method: "POST",
    auth: "abg287:86fd36e606cf7b6b4296c2f9797d5ef8-us13"

  };

  const apiReq = https.request( url, options, ( apiRes ) => {

    if ( apiRes.statusCode === 200 ) {
      res.sendFile( __dirname + "/success.html" );
    }

    else {
      res.sendFile( __dirname + "/failure.html" );
    }

    apiRes.on( "data", ( data ) => {
      console.log( JSON.parse( data ) );
    })

  });

  apiReq.write( jsonData );
  apiReq.end();

});

app.post( "/failure", ( req, res ) => {
  res.redirect( "/" );
});

// OTHER

app.listen( process.env.PORT || localPort, () => {
  console.log( "Server is running on port " + String( localPort ) );
});

// API Key
// 86fd36e606cf7b6b4296c2f9797d5ef8-us13

// List ID
// 2bd99be002
